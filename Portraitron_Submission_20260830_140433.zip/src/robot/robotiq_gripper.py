"""Module to control Robotiq's grippers - tested with HAND-E"""

import socket
import threading
import time
import os
from enum import Enum
from typing import Union, Tuple, OrderedDict

class RobotiqGripper:
    """
    Communicates with the gripper directly, via socket with string commands, leveraging string names for variables.
    """
    # WRITE VARIABLES (CAN ALSO READ)
    ACT = 'ACT'  # act : activate (1 while activated, can be reset to clear fault status)
    GTO = 'GTO'  # gto : go to (will perform go to with the actions set in pos, for, spe)
    ATR = 'ATR'  # atr : auto-release (emergency slow move)
    ADR = 'ADR'  # adr : auto-release direction (open(1) or close(0) during auto-release)
    FOR = 'FOR'  # for : force (0-255)
    SPE = 'SPE'  # spe : speed (0-255)
    POS = 'POS'  # pos : position (0-255), 0 = open
    # READ VARIABLES
    STA = 'STA'  # status (0 = is reset, 1 = activating, 3 = active)
    PRE = 'PRE'  # position request (echo of last commanded position)
    OBJ = 'OBJ'  # object detection (0 = moving, 1 = outer grip, 2 = inner grip, 3 = no object at rest)
    FLT = 'FLT'  # fault (0=ok, see manual for errors if not zero)

    ENCODING = 'UTF-8'  # ASCII and UTF-8 both seem to work

    class GripperStatus(Enum):
        """Gripper status reported by the gripper. The integer values have to match what the gripper sends."""
        RESET = 0
        ACTIVATING = 1
        # UNUSED = 2  # This value is currently not used by the gripper firmware
        ACTIVE = 3

    class ObjectStatus(Enum):
        """Object status reported by the gripper. The integer values have to match what the gripper sends."""
        MOVING = 0
        STOPPED_OUTER_OBJECT = 1
        STOPPED_INNER_OBJECT = 2
        AT_DEST = 3

    def __init__(self, config_path: str = "config/gripper.yaml"):
        """Constructor."""
        self.socket = None
        self.command_lock = threading.Lock()
        self.mock_mode = False
        self.urscript_mode = False
        self.hostname = None
        self._current_pos = 0
        
        self.config = {}
        if os.path.exists(config_path):
            try:
                import yaml
                with open(config_path, 'r') as f:
                    self.config = yaml.safe_load(f) or {}
            except Exception as e:
                print(f"Failed to load gripper config from {config_path}: {e}")

        limits = self.config.get("limits", {})
        self._min_position = limits.get("min_position", 0)
        self._max_position = limits.get("max_position", 255)
        self._min_speed = limits.get("min_speed", 0)
        self._max_speed = limits.get("max_speed", 255)
        self._min_force = limits.get("min_force", 0)
        self._max_force = limits.get("max_force", 255)
        
        timeouts = self.config.get("timeouts", {})
        self._default_socket_timeout = timeouts.get("socket_timeout", 2.0)
        self._reset_sleep = timeouts.get("reset_sleep", 0.5)
        self._reset_wait_sleep = timeouts.get("reset_wait_sleep", 0.01)
        self._activate_sleep = timeouts.get("activate_sleep", 1.0)
        self._activate_wait_sleep = timeouts.get("activate_wait_sleep", 0.01)
        self._move_wait_sleep = timeouts.get("move_wait_sleep", 0.001)
        
        calibration = self.config.get("calibration", {})
        self._calib_speed = calibration.get("speed", 64)
        self._calib_force = calibration.get("force", 1)
        
        defaults = self.config.get("defaults", {})
        self._default_open_speed = defaults.get("open_speed", 100)
        self._default_open_force = defaults.get("open_force", 100)
        self._default_close_speed = defaults.get("close_speed", 100)
        self._default_close_force = defaults.get("close_force", 100)

    def connect(self, hostname: str, port: int, socket_timeout: float = None) -> None:
        """Connects to a gripper at the given address. Falls back to URScript port 30002 if daemon port is unavailable."""
        if socket_timeout is None:
            socket_timeout = self._default_socket_timeout
        self.hostname = hostname
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.socket.settimeout(socket_timeout)
            self.socket.connect((hostname, port))
            self.mock_mode = False
            self.urscript_mode = False
            print(f"Connected directly to Robotiq socket on port {port}.")
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            # Try URScript secondary client interface on port 30002
            try:
                test_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                test_s.settimeout(1.5)
                test_s.connect((hostname, 30002))
                test_s.close()
                self.urscript_mode = True
                self.mock_mode = False
                print(f"Robotiq socket port {port} unavailable. Connected to Gripper via URScript (Port 30002).")
                return
            except Exception:
                pass
            print(f"Warning: Failed to connect to gripper on {hostname}:{port} ({e}).")
            print("Falling back to MOCK MODE. Gripper commands will be simulated.")
            self.mock_mode = True
            self.urscript_mode = False

    def _send_urscript(self, command: str) -> bool:
        if not self.hostname:
            return False
        with self.command_lock:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(3.0)
                    s.connect((self.hostname, 30002))
                    script = f"def rq_script():\n  {command}\nend\nrq_script()\n\n"
                    s.sendall(script.encode('utf-8'))
                return True
            except Exception as e:
                print(f"Failed to send URScript gripper command: {e}")
                return False

    def is_connected(self) -> bool:
        """Returns True if connected either directly or via URScript."""
        return (not self.mock_mode) and (self.urscript_mode or self.socket is not None)

    def disconnect(self) -> None:
        """Closes the connection with the gripper."""
        if not self.mock_mode and self.socket:
            self.socket.close()

    def _set_vars(self, var_dict: OrderedDict[str, Union[int, float]]):
        """Sends the appropriate command via socket to set the value of n variables, and waits for its 'ack' response.
        :param var_dict: Dictionary of variables to set (variable_name, value).
        :return: True on successful reception of ack, false if no ack was received, indicating the set may not
        have been effective.
        """
        if self.mock_mode:
            time.sleep(0.01)
            return True
            
        # construct unique command
        cmd = "SET"
        for variable, value in var_dict.items():
            cmd += f" {variable} {str(value)}"
        cmd += '\n'  # new line is required for the command to finish
        # atomic commands send/rcv
        with self.command_lock:
            self.socket.sendall(cmd.encode(self.ENCODING))
            data = self.socket.recv(1024)
        return self._is_ack(data)

    def _set_var(self, variable: str, value: Union[int, float]):
        """Sends the appropriate command via socket to set the value of a variable, and waits for its 'ack' response.
        :param variable: Variable to set.
        :param value: Value to set for the variable.
        :return: True on successful reception of ack, false if no ack was received, indicating the set may not
        have been effective.
        """
        return self._set_vars(OrderedDict([(variable, value)]))

    def _get_var(self, variable: str):
        """Sends the appropriate command to retrieve the value of a variable from the gripper, blocking until the
        response is received or the socket times out.
        :param variable: Name of the variable to retrieve.
        :return: Value of the variable as integer.
        """
        if self.mock_mode:
            time.sleep(0.01)
            # Return appropriate mock values for the state machine
            if variable == self.STA:
                return self.GripperStatus.ACTIVE.value
            elif variable == self.OBJ:
                return self.ObjectStatus.AT_DEST.value
            elif variable == self.PRE:
                return 0
            elif variable == self.FLT:
                return 0
            return 0
            
        # atomic commands send/rcv
        with self.command_lock:
            cmd = f"GET {variable}\n"
            self.socket.sendall(cmd.encode(self.ENCODING))
            data = self.socket.recv(1024)

        # expect data of the form 'VAR x', where VAR is an echo of the variable name, and X the value
        # note some special variables (like FLT) may send 2 bytes, instead of an integer. We assume integer here
        var_name, value_str = data.decode(self.ENCODING).split()
        if var_name != variable:
            raise ValueError(f"Unexpected response {data} ({data.decode(self.ENCODING)}): does not match '{variable}'")
        value = int(value_str)
        return value

    @staticmethod
    def _is_ack(data: str):
        return data == b'ack'

    def _reset(self):
        """
        Reset the gripper.
        """
        if self.mock_mode:
            return
            
        self._set_var(self.ACT, 0)
        self._set_var(self.ATR, 0)
        while (not self._get_var(self.ACT) == 0 or not self._get_var(self.STA) == 0):
            self._set_var(self.ACT, 0)
            self._set_var(self.ATR, 0)
        time.sleep(self._reset_sleep)

    def activate(self, auto_calibrate: bool = True):
        """Resets the activation flag in the gripper, and sets it back to one, clearing previous fault flags.
        :param auto_calibrate: Whether to calibrate the minimum and maximum positions based on actual motion.
        """
        if self.mock_mode:
            return

        if self.urscript_mode:
            self._send_urscript("rq_activate_and_wait()")
            return
            
        if not self.is_active():
            self._reset()
            while (not self._get_var(self.ACT) == 0 or not self._get_var(self.STA) == 0):
                time.sleep(self._reset_wait_sleep)

            self._set_var(self.ACT, 1)
            time.sleep(self._activate_sleep)
            while (not self._get_var(self.ACT) == 1 or not self._get_var(self.STA) == 3):
                time.sleep(self._activate_wait_sleep)

        # auto-calibrate position range if desired
        if auto_calibrate:
            self.auto_calibrate()

    def is_active(self):
        """Returns whether the gripper is active."""
        if self.urscript_mode:
            return True
        status = self._get_var(self.STA)
        return RobotiqGripper.GripperStatus(status) == RobotiqGripper.GripperStatus.ACTIVE

    def get_min_position(self) -> int:
        """Returns the minimum position the gripper can reach (open position)."""
        return self._min_position

    def get_max_position(self) -> int:
        """Returns the maximum position the gripper can reach (closed position)."""
        return self._max_position

    def get_open_position(self) -> int:
        """Returns what is considered the open position for gripper (minimum position value)."""
        return self.get_min_position()

    def get_closed_position(self) -> int:
        """Returns what is considered the closed position for gripper (maximum position value)."""
        return self.get_max_position()

    def is_open(self):
        """Returns whether the current position is considered as being fully open."""
        return self.get_current_position() <= self.get_open_position()

    def is_closed(self):
        """Returns whether the current position is considered as being fully closed."""
        return self.get_current_position() >= self.get_closed_position()

    def get_current_position(self) -> int:
        """Returns the current position as returned by the physical hardware."""
        if self.urscript_mode:
            return self._current_pos
        return self._get_var(self.POS)

    def auto_calibrate(self, log: bool = True) -> None:
        """Attempts to calibrate the open and closed positions, by slowly closing and opening the gripper.
        :param log: Whether to print the results to log.
        """
        # first try to open in case we are holding an object
        (position, status) = self.move_and_wait_for_pos(self.get_open_position(), self._calib_speed, self._calib_force)
        if RobotiqGripper.ObjectStatus(status) != RobotiqGripper.ObjectStatus.AT_DEST:
            raise RuntimeError(f"Calibration failed opening to start: {str(status)}")

        # try to close as far as possible, and record the number
        (position, status) = self.move_and_wait_for_pos(self.get_closed_position(), self._calib_speed, self._calib_force)
        if RobotiqGripper.ObjectStatus(status) != RobotiqGripper.ObjectStatus.AT_DEST:
            raise RuntimeError(f"Calibration failed because of an object: {str(status)}")
        assert position <= self._max_position
        self._max_position = position

        # try to open as far as possible, and record the number
        (position, status) = self.move_and_wait_for_pos(self.get_open_position(), self._calib_speed, self._calib_force)
        if RobotiqGripper.ObjectStatus(status) != RobotiqGripper.ObjectStatus.AT_DEST:
            raise RuntimeError(f"Calibration failed because of an object: {str(status)}")
        assert position >= self._min_position
        self._min_position = position

        if log:
            print(f"Gripper auto-calibrated to [{self.get_min_position()}, {self.get_max_position()}]")

    def move(self, position: int, speed: int, force: int) -> Tuple[bool, int]:
        """Sends commands to start moving towards the given position, with the specified speed and force.
        :param position: Position to move to [min_position, max_position]
        :param speed: Speed to move at [min_speed, max_speed]
        :param force: Force to use [min_force, max_force]
        :return: A tuple with a bool indicating whether the action it was successfully sent, and an integer with
        the actual position that was requested, after being adjusted to the min/max calibrated range.
        """

        def clip_val(min_val, val, max_val):
            return max(min_val, min(val, max_val))

        clip_pos = clip_val(self._min_position, position, self._max_position)
        clip_spe = clip_val(self._min_speed, speed, self._max_speed)
        clip_for = clip_val(self._min_force, force, self._max_force)

        if self.urscript_mode:
            self._current_pos = clip_pos
            ok = self._send_urscript(f"rq_set_force({clip_for})\nrq_set_speed({clip_spe})\nrq_set_pos({clip_pos})")
            return ok, clip_pos

        # moves to the given position with the given speed and force
        var_dict = OrderedDict([(self.POS, clip_pos), (self.SPE, clip_spe), (self.FOR, clip_for), (self.GTO, 1)])
        return self._set_vars(var_dict), clip_pos

    def move_and_wait_for_pos(self, position: int, speed: int, force: int) -> Tuple[int, ObjectStatus]:  # noqa
        """Sends commands to start moving towards the given position, with the specified speed and force, and
        then waits for the move to complete.
        :param position: Position to move to [min_position, max_position]
        :param speed: Speed to move at [min_speed, max_speed]
        :param force: Force to use [min_force, max_force]
        :return: A tuple with an integer representing the last position returned by the gripper after it notified
        that the move had completed, a status indicating how the move ended (see ObjectStatus enum for details). Note
        that it is possible that the position was not reached, if an object was detected during motion.
        """
        if self.urscript_mode:
            clip_pos = min(self._max_position, max(self._min_position, position))
            clip_spe = min(self._max_speed, max(self._min_speed, speed))
            clip_for = min(self._max_force, max(self._min_force, force))
            self._current_pos = clip_pos
            self._send_urscript(f"rq_set_force({clip_for})\nrq_set_speed({clip_spe})\nrq_move_and_wait({clip_pos})")
            return clip_pos, RobotiqGripper.ObjectStatus.AT_DEST

        set_ok, cmd_pos = self.move(position, speed, force)
        if not set_ok:
            raise RuntimeError("Failed to set variables for move.")

        if self.mock_mode:
            return cmd_pos, RobotiqGripper.ObjectStatus.AT_DEST

        # wait until the gripper acknowledges that it will try to go to the requested position
        while self._get_var(self.PRE) != cmd_pos:
            time.sleep(self._move_wait_sleep)

        # wait until not moving
        cur_obj = self._get_var(self.OBJ)
        while RobotiqGripper.ObjectStatus(cur_obj) == RobotiqGripper.ObjectStatus.MOVING:
            cur_obj = self._get_var(self.OBJ)

        # report the actual position and the object status
        final_pos = self._get_var(self.POS)
        final_obj = cur_obj
        return final_pos, RobotiqGripper.ObjectStatus(final_obj)

    def open(self, speed: int = None, force: int = None):
        if speed is None: speed = self._default_open_speed
        if force is None: force = self._default_open_force
        return self.move_and_wait_for_pos(self.get_open_position(), speed, force)
    
    def close(self, speed: int = None, force: int = None):
        if speed is None: speed = self._default_close_speed
        if force is None: force = self._default_close_force
        return self.move_and_wait_for_pos(self.get_closed_position(), speed, force)